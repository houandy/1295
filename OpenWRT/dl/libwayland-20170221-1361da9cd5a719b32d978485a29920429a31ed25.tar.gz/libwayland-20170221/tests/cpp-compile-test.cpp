/* This source should compile fine with C++ compiler */
#include "wayland-server-protocol.h"

int main() { return 0; }

